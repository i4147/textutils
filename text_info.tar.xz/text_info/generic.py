class AttrDict(dict):

    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self

    def __missing__(self, key, *args, **kwargs):
        return None

    def __getattr__(self, key, *args, **kwargs):
        return None

    def deepdict(self):
        return deepdict(self)


def deepdict(info):
    tp = type(info)

    return (
        dict({k: deepdict(v) for (k, v) in info.items()})
        if tp in {dict, AttrDict}
        else (
            tuple(deepdict(item) for item in info)
            if tp is tuple
            else (
                frozenset(deepdict(item) for item in info)
                if tp is frozenset
                else (
                    [deepdict(item) for item in info]
                    if tp is list
                    else {deepdict(item) for item in info}
                    if tp is set
                    else info
                )
            )
        )
    )


def deepAttrDict(info, preferTuples=False):
    tp = type(info)

    return (
        AttrDict({k: deepAttrDict(v, preferTuples=preferTuples) for (k, v) in info.items()})
        if tp in {dict, AttrDict}
        else (
            tuple(deepAttrDict(item, preferTuples=preferTuples) for item in info)
            if tp is tuple or (tp is list and preferTuples)
            else (
                frozenset(deepAttrDict(item, preferTuples=preferTuples) for item in info)
                if tp is frozenset
                else (
                    [deepAttrDict(item, preferTuples=preferTuples) for item in info]
                    if tp is list
                    else ({deepAttrDict(item, preferTuples=preferTuples) for item in info} if tp is set else info)
                )
            )
        )
    )


def isIterable(value):

    return type(value) is not str and hasattr(value, "__iter__")
