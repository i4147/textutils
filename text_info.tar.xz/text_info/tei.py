
import collections
import re
from textwrap import wrap

from lxml import etree

from ..kit.helpers import console, versionSort, readCfg
from ..kit.files import (
    fileOpen,
    unexpanduser as ux,
    initTree,
    dirExists,
    fileExists,
    scanDir,
    writeYaml,
)
from ..kit.generic import AttrDict

from .helpers import checkSectionModel

from ..tools.xmlschema import Analysis


FACS_MAPPING_YML = "facsMapping.yml"

TASKS_EXCLUDED = {"apptoken", "browse"}

PROGRESS_LIMIT = 5

REFERENCING = dict(
    ptr="target",
    ref="target",
    rs="ref",
)

ZONE_ATTS = (("ulx", 0), ("uly", 0), ("lrx", 100), ("lry", 100))


def getRefs(tag, atts, xmlFile):
    refAtt = REFERENCING.get(tag, None)
    result = []

    if refAtt is not None:
        refVal = atts.get(refAtt, None)
        if refVal is not None and not refVal.startswith("http"):
            for refv in refVal.split():
                parts = refv.split("#", 1)
                if len(parts) == 1:
                    targetFile = refv
                    targetId = ""
                else:
                    (targetFile, targetId) = parts
                if targetFile == "":
                    targetFile = xmlFile
                result.append((refAtt, targetFile, targetId))
    return result


class TEI:
    def __init__(self, sourceDir, cfgFile, verbose=0):
        self.sourceDir = sourceDir
        self.cfgFile = cfgFile
        self.verbose = verbose

        if not dirExists(sourceDir):
            console("Source directory does not exist: {sourceDir}", error=True)
            self.good = False
            return

        self.good = True
        self.severeError = False
        self.fatalError = False

        (ok, settings) = readCfg(cfgFile, "tei", verbose=verbose, plain=True)
        if not ok:
            self.good = False

        param = AttrDict()
        self.param = param

        param.models = settings.get("models", [])
        param.procins = settings.get("procins", False)
        param.zoneBased = settings.get("zoneBased", False)

        sectionModel = settings.get("sectionModel", {})
        sectionModel = checkSectionModel(sectionModel, verbose)

        if not sectionModel:
            self.good = False
            return

        sectionProperties = sectionModel["properties"]
        param.sectionModel = sectionModel["model"]
        param.backMatter = sectionProperties.get("backMatter", None)
        param.templates = settings.get("templates", [])
        param.adaptations = settings.get("adaptations", [])

        templateTrigger = settings.get("templateTrigger", None)
        adaptationTrigger = settings.get("adaptationTrigger", None)

        if templateTrigger is None:
            templateAtt = None
            templateTag = None
        else:
            (tag, att) = templateTrigger.split("@")
            templateAtt = att
            templateTag = tag

        if adaptationTrigger is None:
            adaptationAtt = None
            adaptationTag = None
        else:
            (tag, att) = adaptationTrigger.split("@")
            adaptationAtt = att
            adaptationTag = tag

        triggers = {}
        param.triggers = triggers

        for kind, theAtt, theTag in (
            ("template", templateAtt, templateTag),
            ("adaptation", adaptationAtt, adaptationTag),
        ):
            triggerRe = None

            if theAtt is not None and theTag is not None:
                tagPat = re.escape(theTag)
                triggerRe = re.compile(rf"""<{tagPat}\b[^>]*?{theAtt}=['"]([^'"]+)['"]""")
            triggers[kind] = triggerRe

        if not self.good:
            return

    def inventory(self, schemaDir, reportDir, carryon=False, verbose=None):
        if not self.good:
            return

        if not reportDir:
            console("No report directory specified", error=True)
            self.good = False

        sourceDir = self.sourceDir
        self.schemaDir = schemaDir
        self.reportDir = reportDir
        self.carryon = carryon

        if verbose is None:
            verbose = self.verbose

        param = self.param
        procins = param.procins
        zoneBased = param.zoneBased

        param.kindLabels = dict(
            format="Formatting Attributes",
            keyword="Keyword Attributes",
            rest="Remaining Attributes and Elements",
        )

        out = AttrDict()
        self.out = out

        self.readSchemas(verbose=verbose)
        A = self.A
        self.parser = self.getParser()

        modelXsd = out.modelXsd

        if verbose is None:
            verbose = self.verbose

        if verbose == 1:
            console(f"TEI to TF checking: {ux(sourceDir)} => {ux(reportDir)}")
        if verbose >= 0:
            console(f"Processing instructions are {'treated' if procins else 'ignored'}")
            console("XML validation will be performed")

        baseSchema = modelXsd[None]
        overrides = [override for (model, override) in modelXsd.items() if model is not None]
        A.getElementInfo(baseSchema, overrides, verbose=verbose)
        out.elementDefs = A.elementDefs

        getStore = lambda: collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
        out.report = {x: getStore() for x in param.kindLabels}
        out.errors = []
        out.tagByNs = collections.defaultdict(collections.Counter)
        out.refs = collections.defaultdict(lambda: collections.Counter())
        out.ids = collections.defaultdict(lambda: collections.Counter())
        out.lbParents = collections.Counter()
        out.folders = []
        out.pageScans = {}
        out.facsMapping = {} if zoneBased else {}
        out.facsKind = {}
        out.facsNotDeclared = {}
        out.facsNoId = {}
        out.zoneRegionIncomplete = {}
        out.nProcins = 0
        out.nPagesNoFacs = 0
        out.inFacsimile = False
        out.surfaceId = None
        out.scanFile = None
        out.zoneId = None
        out.zoneRegion = None

        initTree(reportDir)

        self.validate(verbose=verbose)

        for xmlPath in out.toBeInventoried:
            self.fileInventory(xmlPath)

        if not self.good:
            self.good = False

        if verbose >= 0:
            console("")

        self.writeElemTypes(verbose=verbose)

        if not self.severeError:
            self.writeErrors(verbose=verbose)

        if self.good or carryon:
            self.writeFacs(verbose=verbose)
            self.writeNamespaces(verbose=verbose)
            self.writeReport(verbose=verbose)
            self.writeIdRefs(verbose=verbose)
            self.writeLbParents(verbose=verbose)

    def validate(self, verbose=0):
        sourceDir = self.sourceDir
        carryon = self.carryon
        A = self.A

        param = self.param
        sectionModel = param.sectionModel

        out = self.out
        errors = out.errors
        modelInfo = out.modelInfo
        out.toBeInventoried = []

        xmlFilesByModel = collections.defaultdict(list)

        out.files = self.getXML()
        self.writeFileInfo()

        if sectionModel == "I":
            for xmlFolder, xmlFiles in out.files:
                msg = "Start " if verbose >= 0 else "\t"

                if verbose >= 0:
                    console(f"\t{msg}folder {xmlFolder}")

                for xmlFile in xmlFiles:
                    xmlPath = f"{xmlFolder}/{xmlFile}"
                    xmlFullPath = f"{sourceDir}/{xmlPath}"
                    (model, adapt, tpl) = self.getSwitches(xmlFullPath)
                    xmlFilesByModel[model].append(xmlPath)

        elif sectionModel == "II":
            xmlFile = out.files

            if xmlFile is None:
                console("No XML files found!", error=True)
                return False

            xmlFullPath = f"{sourceDir}/{xmlFile}"
            (model, adapt, tpl) = self.getSwitches(xmlFullPath)
            xmlFilesByModel[model].append(xmlFile)

        elif sectionModel == "III":
            for xmlFile in out.files:
                xmlFullPath = f"{sourceDir}/{xmlFile}"
                (model, adapt, tpl) = self.getSwitches(xmlFullPath)
                xmlFilesByModel[model].append(xmlFile)

        good = True
        severeError = False
        fatalError = False

        for model, xmlPaths in xmlFilesByModel.items():
            if verbose >= 0:
                console(f"{len(xmlPaths)} {model or 'TEI'} file(s) ...")

            thisGood = True

            if verbose >= 0:
                console("\tValidating ...")

            schemaFile = modelInfo.get(model, None)

            if schemaFile is None:
                if verbose >= 0:
                    console(f"\t\tNo schema file for {model}")
                if good is not None and good is not False:
                    good = None
                continue

            (thisGood, info, theseErrors) = A.validate(
                True,
                schemaFile,
                [f"{sourceDir}/{xmlPath}" for xmlPath in xmlPaths],
            )
            if thisGood == -1:
                severeError = True

            elif thisGood is None:
                fatalError = True

                console("Fatal error in one of the XML files", error=True)

                rInfo = [*info]
                rTheseErrors = [*theseErrors]
                rXmlPaths = [*xmlPaths]

                iteration = 0
                maxIter = 20

                while True:
                    iteration += 1

                    if iteration > maxIter:
                        console(
                            f"Stopped looking for more fatal errors after {maxIter} iterations",
                            error=True,
                        )
                        break

                    fatalPath = None

                    for e in rTheseErrors:
                        kind = e[4]

                        if kind == "fatal":
                            (folder, file) = e[0:2]
                            fatalPath = f"{folder}/{file}"

                    if fatalPath is None:
                        console("No more fatal errors", error=True)
                        break

                    console(
                        f"Check for more fatal errors (iteration {iteration} of up to {maxIter}) after {fatalPath}",
                        error=True,
                    )
                    newRXmlPaths = []

                    skipping = True

                    for xmlPath in rXmlPaths:
                        if skipping:
                            if xmlPath == fatalPath:
                                skipping = False
                        else:
                            newRXmlPaths.append(xmlPath)

                    if not len(newRXmlPaths):
                        console("No more files to examine", error=True)
                        break

                    rXmlPaths = newRXmlPaths
                    (thisRGood, rInfo, rTheseErrors) = A.validate(
                        True,
                        schemaFile,
                        [f"{sourceDir}/{xmlPath}" for xmlPath in rXmlPaths],
                        verbose=True,
                    )

                    info.extend(rInfo)
                    theseErrors.extend(rTheseErrors)

                    if thisRGood is not None:
                        console("Last fatal error encountered", error=True)
                        break

            for line in info:
                if verbose >= 0:
                    console(f"\t\t{line}")

            if severeError:
                for err in theseErrors:
                    console(err, error=True)

                self.severeError = True
                break

            if fatalError:
                self.fatalError = True

            if not thisGood:
                good = False

                errors.extend(theseErrors)

                if not carryon:
                    continue

            if (good or carryon) and verbose >= 0:
                out.toBeInventoried.extend(xmlPaths)

    def analyse(self, root, xmlPath):
        FORMAT_ATTS = set(
            """
            dim
            level
            place
            rend
        """.strip().split()
        )

        KEYWORD_ATTS = set(
            """
            facs
            form
            function
            lang
            reason
            type
            unit
            who
        """.strip().split()
        )

        TRIM_ATTS = set(
            """
            id
            key
            target
            value
        """.strip().split()
        )

        NUM_RE = re.compile(r"""[0-9]""", re.S)

        param = self.param
        procins = param.procins
        zoneBased = param.zoneBased

        out = self.out
        report = out.report
        tagByNs = out.tagByNs
        refs = out.refs
        ids = out.ids
        lbParents = out.lbParents
        pageScans = out.pageScans
        facsMapping = out.facsMapping
        facsKind = out.facsKind
        facsNotDeclared = out.facsNotDeclared
        facsNoId = out.facsNoId
        zoneRegionIncomplete = out.zoneRegionIncomplete

        def nodeInfo(xnode):
            if procins and isinstance(xnode, etree._ProcessingInstruction):
                target = xnode.target
                tag = f"?{target}"
                ns = ""
                out.nProcins += 1
            else:
                qName = etree.QName(xnode.tag)
                tag = qName.localname
                ns = qName.namespace

            atts = {etree.QName(k).localname: v for (k, v) in xnode.attrib.items()}

            tagByNs[tag][ns] += 1

            if tag == "lb":
                parentTag = etree.QName(xnode.getparent().tag).localname
                lbParents[parentTag] += 1
            elif tag == "pb":
                facsv = atts.get("facs", "")

                if zoneBased:
                    facsv = facsv.removeprefix("#")

                    if facsv:
                        (scanName, scanRegion) = facsMapping[xmlPath].get(facsv, ["", "full"])

                        if not scanName:
                            facsNotDeclared[xmlPath].add(facsv)

                if facsv:
                    pageScans[xmlPath].append(facsv)
                else:
                    out.nPagesNoFacs += 1
            elif zoneBased:
                if tag == "facsimile":
                    out.inFacsimile = True
                elif out.inFacsimile:
                    if tag == "surface":
                        out.surfaceId = atts.get("id", None)
                        out.scanFile = None

                        if not out.surfaceId:
                            facsNoId[xmlPath]["surface"] += 1
                    elif tag == "zone":
                        out.zoneId = atts.get("id", None)

                        if out.zoneId:
                            out.zoneRegion = []

                            for a, aDefault in ZONE_ATTS:
                                aVal = atts.get(a, None)

                                if aVal is None:
                                    aVal = aDefault
                                    zoneRegionIncomplete.setdefault(out.zoneId, {})[a] = f"None => {aDefault}"
                                elif aVal.isdecimal():
                                    aVal = int(aVal)
                                else:
                                    zoneRegionIncomplete.setdefault(out.zoneId, {})[a] = f"{aVal} => {aDefault}"

                                out.zoneRegion.append(aVal)

                            (ulx, uly, lrx, lry) = out.zoneRegion
                            out.zoneRegion = f"pct:{ulx},{uly},{lrx - ulx},{lry - uly}"

                            if out.scanFile:
                                facsMapping[xmlPath][out.zoneId] = [
                                    out.scanFile,
                                    out.zoneRegion,
                                ]
                                facsKind[xmlPath][out.zoneId] = "zone"
                        else:
                            facsNoId[xmlPath]["zone"] += 1

                    elif tag == "graphic":
                        thisScanFile = atts.get("url", None)

                        if thisScanFile is not None:
                            if out.zoneId:
                                facsMapping[xmlPath][out.zoneId] = [
                                    thisScanFile,
                                    out.zoneRegion,
                                ]
                                facsKind[xmlPath][out.zoneId] = "zone"
                            else:
                                out.scanFile = thisScanFile
                            if out.surfaceId:
                                facsMapping[xmlPath][out.surfaceId] = [
                                    out.scanFile,
                                    "full",
                                ]
                                facsKind[xmlPath][out.surfaceId] = "surface"

            if len(atts) == 0:
                kind = "rest"
                report[kind][tag][""][""] += 1
            else:
                idv = atts.get("id", None)

                if idv is not None:
                    ids[xmlPath][idv] += 1

                for refAtt, targetFile, targetId in getRefs(tag, atts, xmlPath):
                    refs[xmlPath][(targetFile, targetId)] += 1

                for k, v in atts.items():
                    kind = "format" if k in FORMAT_ATTS else "keyword" if k in KEYWORD_ATTS else "rest"
                    dest = report[kind]

                    if kind == "rest":
                        vTrim = "X" if k in TRIM_ATTS else NUM_RE.sub("N", v)
                        dest[tag][k][vTrim] += 1
                    else:
                        words = v.strip().split()
                        for w in words:
                            dest[tag][k][w.strip()] += 1

            for child in xnode.iterchildren(
                tag=((etree.Element, etree.ProcessingInstruction) if procins else etree.Element)
            ):
                nodeInfo(child)

            if zoneBased:
                if tag == "facsimile":
                    out.inFacsimile = False
                elif out.inFacsimile:
                    if tag == "surface":
                        out.surfaceId = None
                        out.scanFile = None
                    elif tag == "zone":
                        out.zoneId = None

        nodeInfo(root)

    def fileInventory(self, xmlPath):
        sourceDir = self.sourceDir
        xmlFullPath = f"{sourceDir}/{xmlPath}"

        out = self.out
        ids = out.ids
        pageScans = out.pageScans
        facsMapping = out.facsMapping
        facsKind = out.facsKind
        facsNotDeclared = out.facsNotDeclared
        facsNoId = out.facsNoId

        pageScans[xmlPath] = []
        facsMapping[xmlPath] = {}
        facsKind[xmlPath] = {}
        facsNotDeclared[xmlPath] = set()
        facsNoId[xmlPath] = collections.Counter()

        root = self.parseXML(xmlPath, xmlFullPath)

        if root is None:
            return

        ids[xmlPath][""] = 1
        self.analyse(root, xmlPath)

    def writeFileInfo(self, verbose=0):

        reportDir = self.reportDir
        infoFile = f"{reportDir}/files.yml"

        out = self.out
        info = out.files

        writeYaml(info, asFile=infoFile)

    def writeErrors(self, verbose=0):

        reportDir = self.reportDir
        errorFile = f"{reportDir}/errors.txt"

        out = self.out
        errors = out.errors

        nErrors = 0
        nFiles = 0

        with fileOpen(errorFile, mode="w") as fh:
            prevFolder = None
            prevFile = None

            for folder, file, line, col, kind, text in errors:
                newFolder = prevFolder != folder
                newFile = newFolder or prevFile != file

                if newFile:
                    nFiles += 1

                if kind in {"error", "fatal"}:
                    nErrors += 1

                indent1 = f"{folder}\n\t" if newFolder else "\t"
                indent2 = f"{file}\n\t\t" if newFile else "\t"
                loc = f"{line or ''}:{col or ''}"
                text = "\n".join(wrap(text, width=80, subsequent_indent="\t\t\t"))
                fh.write(f"{indent1}{indent2}{loc} {kind or ''} {text}\n")
                prevFolder = folder
                prevFile = file

        if nErrors:
            console(
                (f"{nErrors} validation error(s) in {nFiles} file(s) written to {errorFile}"),
                error=True,
            )
        else:
            if verbose >= 0:
                console("Validation OK")

    def writeFacs(self, verbose=0):
        reportDir = self.reportDir
        infoFile = f"{reportDir}/facsNoId.yml"

        param = self.param
        zoneBased = param.zoneBased

        out = self.out
        pageScans = out.pageScans
        facsMapping = out.facsMapping
        facsKind = out.facsKind
        facsNotDeclared = out.facsNotDeclared
        facsNoId = out.facsNoId
        zoneRegionIncomplete = out.zoneRegionIncomplete
        nPagesNoFacs = out.nPagesNoFacs

        writeYaml(
            {f: {k: n for (k, n) in v.items() if n} for (f, v) in facsNoId.items() if len(v)},
            asFile=infoFile,
        )

        nSurfaces = sum(x["surface"] for x in facsNoId.values())
        nZones = sum(x["zone"] for x in facsNoId.values())

        if verbose >= 0:
            pluralS = "" if nSurfaces == 1 else "s"
            pluralZ = "" if nZones == 1 else "s"

            if nSurfaces:
                console(f"{nSurfaces} surface{pluralS} without id")

            if nZones:
                console(f"{nZones} zone{pluralZ} without id")

        infoFile = f"{reportDir}/facs.yml"
        nItems = sum(len(x) for x in pageScans.values())
        nUnique = sum(len(set(x)) for x in pageScans.values())

        writeYaml(pageScans, asFile=infoFile)

        if verbose >= 0:
            plural = "" if nPagesNoFacs == 1 else "s"
            console(f"{nPagesNoFacs} pagebreak{plural} without facs attribute.")

            plural = "" if nItems == 1 else "s"
            console(f"{nItems} pagebreak{plural} encountered.")
            plural = "" if nUnique == 1 else "s"
            console(f"{nUnique} distinct scan{plural} referred to by pagebreaks.")

        if not zoneBased:
            return

        infoFile = f"{reportDir}/facsKind.yml"
        writeYaml(facsKind, asFile=infoFile)
        infoFile = f"{reportDir}/{FACS_MAPPING_YML}"
        writeYaml(facsMapping, asFile=infoFile)

        if verbose >= 0:
            nSurfaces = sum(sum(1 for y in x.values() if y == "surface") for x in facsKind.values())
            nZones = sum(sum(1 for y in x.values() if y == "zone") for x in facsKind.values())
            plural = "" if nSurfaces == 1 else "s"
            console(f"{nSurfaces} surface{plural} declared")
            plural = "" if nZones == 1 else "s"
            console(f"{nZones} zone{plural} declared")

            nItems = sum(len(x) for x in facsMapping.values())
            plural = "" if nItems == 1 else "s"
            console(f"{nItems} scan{plural} declared and mapped.")

        infoFile = f"{reportDir}/facsProblems.yml"
        facsNotUsed = {}

        for xmlPath, mapping in facsMapping.items():
            facsEncountered = set(pageScans[xmlPath])
            thisFacsNotUsed = {}

            for facs in mapping:
                if facs not in facsEncountered:
                    kind = facsKind[xmlPath][facs]
                    thisFacsNotUsed.setdefault(kind, []).append(facs)

            if len(thisFacsNotUsed):
                facsNotUsed[xmlPath] = thisFacsNotUsed

        facsProblems = {}

        nFacsNotDeclared = sum(len(x) for x in facsNotDeclared.values())
        nSurfacesNotUsed = sum(len(x.get("surface", [])) for x in facsNotUsed.values())
        nZonesNotUsed = sum(len(x.get("zone", [])) for x in facsNotUsed.values())

        if nFacsNotDeclared:
            plural = "" if nFacsNotDeclared == 1 else "s"
            console(f"{nFacsNotDeclared} undeclared scan{plural}", error=True)
            facsProblems["facsNotDeclared"] = {xmlPath: sorted(x) for (xmlPath, x) in facsNotDeclared.items() if len(x)}

        if nSurfacesNotUsed:
            plural = "" if nSurfacesNotUsed == 1 else "s"
            console(f"{nSurfacesNotUsed} unused surface{plural}", error=True)
        if nZonesNotUsed:
            plural = "" if nZonesNotUsed == 1 else "s"
            console(f"{nZonesNotUsed} unused zone{plural}", error=True)

        facsProblems["facsNotUsed"] = facsNotUsed

        writeYaml(facsProblems, asFile=infoFile)

        infoFile = f"{reportDir}/zoneErrors.yml"
        nIncomplete = len(zoneRegionIncomplete)
        plural = "" if nIncomplete == 1 else "s"

        if nIncomplete:
            console(f"{nIncomplete} missing zone region specifier{plural}", error=True)

            console(f"See {infoFile}", error=True)

        writeYaml(zoneRegionIncomplete, asFile=infoFile)

    def writeNamespaces(self, verbose=0):
        reportDir = self.reportDir
        errorFile = f"{reportDir}/namespaces.txt"

        param = self.param
        procins = param.procins

        out = self.out
        tagByNs = out.tagByNs
        nProcins = out.nProcins

        nErrors = 0

        nTags = len(tagByNs)

        with fileOpen(errorFile, mode="w") as fh:
            for tag, nsInfo in sorted(tagByNs.items(), key=lambda x: (-len(x[1]), x[0])):
                label = "OK"
                nNs = len(nsInfo)
                if nNs > 1:
                    nErrors += 1
                    label = "XX"

                for ns, amount in sorted(nsInfo.items(), key=lambda x: (-x[1], x[0])):
                    fh.write(f"{label} {nNs:>2} namespace for {tag:<16} : {amount:>5}x {ns}\n")

        if verbose >= 0:
            if procins:
                plural = "" if nProcins == 1 else "s"
                console(f"{nProcins} processing instruction{plural} encountered.")

            console(
                (
                    f"{nTags} tags of which {nErrors} with multiple namespaces written to {errorFile}"
                    if verbose >= 0 or nErrors
                    else "Namespaces OK"
                ),
                error=nErrors > 0,
            )

    def writeReport(self, verbose=0):
        reportDir = self.reportDir
        reportFile = f"{reportDir}/elements.txt"

        param = self.param
        kindLabels = param.kindLabels

        out = self.out
        report = out.report

        with fileOpen(reportFile, mode="w") as fh:
            fh.write("Inventory of tags and attributes in the source XML file(s).\nContains the following sections:\n")
            for label in kindLabels.values():
                fh.write(f"\t{label}\n")
            fh.write("\n\n")

            infoLines = 0

            def writeAttInfo(tag, att, attInfo):
                nonlocal infoLines
                nl = "" if tag == "" else "\n"
                tagRep = "" if tag == "" else f"<{tag}>"
                attRep = "" if att == "" else f"{att}="
                atts = sorted(attInfo.items())
                (val, amount) = atts[0]
                fh.write(f"{nl}\t{tagRep:<18} {attRep:<11} {amount:>7}x {val}\n")
                infoLines += 1

                for val, amount in atts[1:]:
                    fh.write(f"""\t{"":<18} {"":<11} {amount:>7}x {val}\n""")
                    infoLines += 1

            def writeTagInfo(tag, tagInfo):
                nonlocal infoLines
                tags = sorted(tagInfo.items())
                (att, attInfo) = tags[0]
                writeAttInfo(tag, att, attInfo)
                infoLines += 1
                for att, attInfo in tags[1:]:
                    writeAttInfo("", att, attInfo)

            for kind, label in kindLabels.items():
                fh.write(f"\n{label}\n")
                for tag, tagInfo in sorted(report[kind].items()):
                    writeTagInfo(tag, tagInfo)

        if verbose >= 0:
            console(f"{infoLines} info line(s) written to {reportFile}")

    def writeElemTypes(self, verbose=0):
        reportDir = self.reportDir

        out = self.out
        elementDefs = out.elementDefs
        modelInv = out.modelInv

        elemsCombined = {}
        modelSet = set()

        for schemaOverride, eDefs in elementDefs.items():
            model = modelInv[schemaOverride]
            modelSet.add(model)
            for tag, (typ, mixed) in eDefs.items():
                elemsCombined.setdefault(tag, {}).setdefault(model, {})
                elemsCombined[tag][model]["typ"] = typ
                elemsCombined[tag][model]["mixed"] = mixed

        tagReport = {}

        for tag, tagInfo in elemsCombined.items():
            tagLines = []
            tagReport[tag] = tagLines

            if None in tagInfo:
                teiInfo = tagInfo[None]
                teiTyp = teiInfo["typ"]
                teiMixed = teiInfo["mixed"]
                teiTypRep = "??" if teiTyp is None else typ
                teiMixedRep = "??" if teiMixed is None else "mixed" if teiMixed else "pure"
                mds = ["TEI"]

                for model in sorted(x for x in tagInfo if x is not None):
                    info = tagInfo[model]
                    typ = info["typ"]
                    mixed = info["mixed"]
                    if typ == teiTyp and mixed == teiMixed:
                        mds.append(model)
                    else:
                        typRep = "" if typ == teiTyp else "??" if typ is None else typ
                        mixedRep = (
                            "" if mixed == teiMixed else ("??" if mixed is None else "mixed" if mixed else "pure")
                        )
                        tagLines.append((tag, [model], typRep, mixedRep))
                tagLines.insert(0, (tag, mds, teiTypRep, teiMixedRep))
            else:
                for model in sorted(tagInfo):
                    info = tagInfo[model]
                    typ = info["typ"]
                    mixed = info["mixed"]
                    typRep = "??" if typ is None else typ
                    mixedRep = "??" if mixed is None else "mixed" if mixed else "pure"
                    tagLines.append((tag, [model], typRep, mixedRep))

        reportFile = f"{reportDir}/types.txt"

        with fileOpen(reportFile, mode="w") as fh:
            for tag in sorted(tagReport):
                tagLines = tagReport[tag]

                for tag, mds, typ, mixed in tagLines:
                    model = ",".join(mds)
                    fh.write(f"{tag:<18} {model:<18} {typ or '':<7} {mixed or '':<5}\n")

        if verbose >= 0:
            console(f"{len(elemsCombined)} tag(s) type info written to {reportFile}")

    def writeLbParents(self, verbose=0):
        reportDir = self.reportDir
        reportFile = f"{reportDir}/lb-parents.txt"

        out = self.out
        lbParents = out.lbParents

        with fileOpen(reportFile, "w") as fh:
            for parent, n in sorted(lbParents.items()):
                fh.write(f"{n:>5} x {parent}\n")

        if verbose >= 0:
            console(f"lb-parent info written to {reportFile}")

    def writeIdRefs(self, verbose=0):
        reportDir = self.reportDir
        reportIdFile = f"{reportDir}/ids.txt"
        reportRefFile = f"{reportDir}/refs.txt"

        out = self.out
        refs = out.refs
        ids = out.ids

        ih = fileOpen(reportIdFile, mode="w")
        rh = fileOpen(reportRefFile, mode="w")

        refdIds = collections.Counter()
        missingIds = set()

        totalRefs = 0
        totalRefsU = 0

        totalResolvable = 0
        totalResolvableU = 0
        totalDangling = 0
        totalDanglingU = 0

        seenItems = set()

        for file, items in refs.items():
            rh.write(f"{file}\n")

            resolvable = 0
            resolvableU = 0
            dangling = 0
            danglingU = 0

            for item, n in sorted(items.items()):
                totalRefs += n

                if item in seenItems:
                    newItem = False
                else:
                    seenItems.add(item)
                    newItem = True
                    totalRefsU += 1

                (target, idv) = item

                if target not in ids or idv not in ids[target]:
                    status = "dangling"
                    dangling += n

                    if newItem:
                        missingIds.add((target, idv))
                        danglingU += 1
                else:
                    status = "ok"
                    resolvable += n
                    refdIds[(target, idv)] += n

                    if newItem:
                        resolvableU += 1
                rh.write(f"\t{status:<10} {n:>5} x {target} # {idv}\n")

            msgs = (
                f"\tDangling:   {dangling:>4} x {danglingU:>4}",
                f"\tResolvable: {resolvable:>4} x {resolvableU:>4}",
            )
            for msg in msgs:
                rh.write(f"{msg}\n")

            totalResolvable += resolvable
            totalResolvableU += resolvableU
            totalDangling += dangling
            totalDanglingU += danglingU

        if verbose >= 0:
            console(f"Refs written to {reportRefFile}")
            msgs = (
                f"\tresolvable: {totalResolvableU:>4} in {totalResolvable:>4}",
                f"\tdangling:   {totalDanglingU:>4} in {totalDangling:>4}",
                f"\tALL:        {totalRefsU:>4} in {totalRefs:>4} ",
            )
            for msg in msgs:
                console(msg)

        totalIds = 0
        totalIdsU = 0
        totalIdsM = 0
        totalIdsRefd = 0
        totalIdsRefdU = 0
        totalIdsUnused = 0

        for file, items in ids.items():
            totalIds += len(items)

            ih.write(f"{file}\n")

            unique = 0
            multiple = 0
            refd = 0
            refdU = 0
            unused = 0

            for item, n in sorted(items.items()):
                nRefs = refdIds.get((file, item), 0)

                if n == 1:
                    unique += 1
                else:
                    multiple += 1

                if nRefs == 0:
                    unused += 1
                else:
                    refd += nRefs
                    refdU += 1

                status1 = f"{n}x"
                plural = "" if nRefs == 1 else "s"
                status2 = f"{nRefs}ref{plural}"

                ih.write(f"\t{status1:<8} {status2:<8} {item}\n")

            msgs = (
                f"\tUnique:     {unique:>4}",
                f"\tNon-unique: {multiple:>4}",
                f"\tUnused:     {unused:>4}",
                f"\tReferenced: {refd:>4} x {refdU:>4}",
            )
            for msg in msgs:
                ih.write(f"{msg}\n")

            totalIdsU += unique
            totalIdsM += multiple
            totalIdsRefdU += refdU
            totalIdsRefd += refd
            totalIdsUnused += unused

        if verbose >= 0:
            console(f"Ids written to {reportIdFile}")
            msgs = (
                f"\treferenced: {totalIdsRefdU:>4} by {totalIdsRefd:>4}",
                f"\tnon-unique: {totalIdsM:>4}",
                f"\tunused:     {totalIdsUnused:>4}",
                f"\tALL:        {totalIdsU:>4} in {totalIds:>4}",
            )
            for msg in msgs:
                console(msg)

    def readSchemas(self, verbose=0):
        schemaDir = self.schemaDir

        param = self.param
        models = param.models

        out = self.out
        out.modelXsd = {}
        out.modelMap = {}
        out.modelInfo = {}
        out.modelInv = {}

        A = Analysis(verbose=verbose)
        self.A = A

        newModels = []
        schemaFiles = dict(rng={}, xsd={})

        for model in [None] + models:
            if type(model) is dict:
                (model, href) = list(model.items())[0]
                out.modelMap[href] = model

            if model is not None:
                newModels.append(model)

            for kind in ("rng", "xsd"):
                schemaFile = A.getBaseSchema()[kind] if model is None else f"{schemaDir}/{model}.{kind}"
                if fileExists(schemaFile):
                    schemaFiles[kind][model] = schemaFile
                    if kind == "rng" or kind == "xsd" and model not in schemaFiles["rng"]:
                        out.modelInfo[model] = schemaFile

            if model in schemaFiles["rng"] and model not in schemaFiles["xsd"]:
                schemaFileXsd = f"{schemaDir}/{model}.xsd"
                result = A.fromrelax(schemaFiles["rng"][model], schemaFileXsd)

                if not result:
                    console(f"Could not convert relax schema {model} to xsd", error=True)
                    self.good = False

                    if result is None:
                        self.severeError = True
                        return

                schemaFiles["xsd"][model] = schemaFileXsd

        baseSchema = schemaFiles["xsd"][None]
        out.modelXsd[None] = baseSchema
        out.modelInv[(baseSchema, None)] = None

        for model in newModels:
            override = schemaFiles["xsd"][model]
            out.modelXsd[model] = override
            out.modelInv[(baseSchema, override)] = model

    def getSwitches(self, xmlPath):
        verbose = self.verbose
        A = self.A

        param = self.param
        models = param.models
        templates = param.templates
        adaptations = param.adaptations
        triggers = param.triggers

        out = self.out
        modelMap = out.modelMap

        text = None
        found = {}

        for kind, allOfKind in (
            ("model", models),
            ("adaptation", adaptations),
            ("template", templates),
        ):
            if text is None:
                with fileOpen(xmlPath) as fh:
                    text = fh.read()

            found[kind] = None

            if kind == "model":
                result = A.getModel(text, modelMap)
                if result is None or result == "tei_all":
                    result = None
            else:
                result = None
                triggerRe = triggers[kind]
                if triggerRe is not None:
                    match = triggerRe.search(text)
                    result = match.group(1) if match else None

            if result is not None and result not in allOfKind:
                if verbose >= 0:
                    console(f"unavailable {kind} {result} in {ux(xmlPath)}")
                result = None
            found[kind] = result

        return (found["model"], found["adaptation"], found["template"])

    def getParser(self):
        param = self.param
        procins = param.procins

        return etree.XMLParser(
            remove_blank_text=False,
            collect_ids=False,
            remove_comments=True,
            remove_pis=not procins,
            huge_tree=True,
        )

    def parseXML(self, fileName, fileOrText):
        parser = self.parser

        try:
            tree = etree.parse(fileOrText, parser)
            result = tree.getroot()
        except Exception as e:
            console(f"{fileName}: {str(e)}", error=True)
            result = None

        return result

    def getXML(self):
        verbose = self.verbose
        sourceDir = self.sourceDir

        param = self.param
        sectionModel = param.sectionModel

        if verbose == 1:
            console(f"Section model {sectionModel}")

        if sectionModel == "I":
            backMatter = param.backMatter

            IGNORE = "__ignore__"

            xmlFilesRaw = collections.defaultdict(list)

            with scanDir(sourceDir) as dh:
                for folder in dh:
                    folderName = folder.name

                    if folderName == IGNORE:
                        continue
                    if not folder.is_dir():
                        continue
                    with scanDir(f"{sourceDir}/{folderName}") as fh:
                        for file in fh:
                            fileName = file.name

                            if not (fileName.lower().endswith(".xml") and file.is_file()):
                                continue
                            xmlFilesRaw[folderName].append(fileName)

            xmlFiles = []
            hasBackMatter = False

            for folderName in sorted(xmlFilesRaw, key=versionSort):
                if folderName == backMatter:
                    hasBackMatter = True
                else:
                    fileNames = xmlFilesRaw[folderName]
                    xmlFiles.append([folderName, sorted(fileNames)])

            if hasBackMatter:
                fileNames = xmlFilesRaw[backMatter]
                xmlFiles.append([backMatter, sorted(fileNames)])

            return xmlFiles

        if sectionModel == "II":
            xmlFile = None

            with scanDir(sourceDir) as fh:
                for file in fh:
                    fileName = file.name

                    if not (fileName.lower().endswith(".xml") and file.is_file()):
                        continue

                    xmlFile = fileName
                    break
            return xmlFile

        if sectionModel == "III":
            xmlFiles = []

            with scanDir(sourceDir) as fh:
                for file in fh:
                    fileName = file.name

                    if not (fileName.lower().endswith(".xml") and file.is_file()):
                        continue

                    xmlFiles.append(fileName)

            return sorted(xmlFiles)
