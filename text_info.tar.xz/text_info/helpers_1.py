import os
import sys
import time
import re
from subprocess import run as run_cmd, CalledProcessError
from datetime import datetime as dt, timezone, UTC
import unicodedata


from .files import readYaml, unexpanduser as ux


TZ_RE = re.compile(r"""(?:Z|(?:[+-][0-9:]+))$""")
LETTER = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")

SEP_RE = re.compile(r"[\n\t ,]+")
STRIP_RE = re.compile(r"(?:^[\n\t ,]+)|(?:[\n\t ,]+$)", re.S)
VAR_RE = re.compile(r"\{([^}]+?)(:[^}]*)?\}")
MSG_LINE_RE = re.compile(r"^( *[0-9]+) (.*)$")
NUM_ALFA_RE = re.compile(r"^([0-9]*)([^0-9]*)(.*)$")
WHITE_RE = re.compile(r"""\s+""")
TO_ASCII_DEF = dict(
    ñ="n",
    ø="o",
    ç="c",
)
"""Undecomposable UNICODE characters mapped to their related ASCII characters."""


TO_ASCII = {}

for u, a in TO_ASCII_DEF.items():
    TO_ASCII[u] = a
    TO_ASCII[u.upper()] = a.upper()


ALPHABET = "abcdefghijklmnopqrstuvwxyz"
LETTER = set(ALPHABET) | set(ALPHABET.upper()) | set("()-")
VALID = set("_0123456789") | LETTER
SEQ_RE = re.compile(r"""^(.*)\(([0-9]+)\)$""", re.S)

VAR_RE = re.compile(
    r"""
        (\$?)
        \{
        ([a-z0-9_]+)
        \}
    """,
    re.X | re.S | re.I,
)


def makeVarReplace(info, found, notFound):
    def varReplace(match):
        (fullName, kind, name) = match.group(0, 1, 2)
        fullName = fullName.replace("{", "").replace("}", "")

        result = var(name) if kind else info.get(name, None)

        if result is None:
            notFound.append(fullName)
            result = fullName
        else:
            found[fullName] = result

        return result

    return varReplace


def normalize(text):
    return WHITE_RE.sub(" ", text.strip()).lower()


def toAscii(text, lowercase=True):
    text = WHITE_RE.sub("_", text.strip())

    if lowercase:
        text = text.lower()

    text = "".join(TO_ASCII.get(c, c) for c in unicodedata.normalize("NFD", text) if unicodedata.category(c) != "Mn")
    text = "".join(c if c in VALID else "x" for c in text)
    return text


def makeAsciiUnique(text, among):

    candidate = toAscii(text)

    if candidate not in among:
        return candidate

    match = SEQ_RE.match(candidate)
    (base, seq) = match.group(1, 2) if match else (candidate, None)

    if seq is not None:
        seq = int(seq)

    oSeqs = set()

    for other in sorted(among):
        match = SEQ_RE.match(other)
        (oBase, oSeq) = match.group(1, 2) if match else (other, None)

        if oBase == base:
            oSeqs.add(None if oSeq is None else int(oSeq))

    if len(oSeqs):
        if seq in oSeqs:
            newSeqRep = f"({max((oSeq for oSeq in oSeqs if oSeq is not None), default=0) + 1})"
        else:
            newSeqRep = "" if seq is None else f"({seq})"
    else:
        newSeqRep = "(1)"
    return f"{base}{newSeqRep}"


def htmlEsc(val, math=False):

    return (
        ""
        if val is None
        else (
            (str(val).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
            if math
            else (
                str(val).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("$", "<span>$</span>")
            )
        )
    )


def utcnow():
    return dt.now(timezone.utc)


def isonow():
    return TZ_RE.sub("Z", utcnow().isoformat(timespec="seconds", sep="T"))


def pseudoisonow():
    return isonow().replace(":", "-")


def getDelta(days, refDate, iso=True):
    if refDate is None:
        return 0

    delta = utcnow() - (dt.fromisoformat(refDate) if iso else dt.fromtimestamp(refDate, tz=UTC))
    deltaDays = delta.days + delta.seconds / 86400

    return deltaDays


def lessAgo(days, refDate, iso=True):
    return 0 <= getDelta(days, refDate, iso=iso) < days


def versionSort(x):
    parts = []

    for p in x.split("."):
        match = NUM_ALFA_RE.match(p)
        (num, alfa, rest) = match.group(1, 2, 3)
        parts.append((int(num) if num else 0, alfa, rest))

    return tuple(parts)


def plainify(value):
    if value is None:
        return ""

    tp = type(value)

    if tp is list:
        return [plainify(v) for v in value]

    if tp is dict:
        return [f"{k}: {plainify(v)}" for (k, v) in value.items()]

    return str(value)


def ucFirst(x):
    if not x:
        return ""

    return x[0].upper() + x[1:]


def prettify(x):
    return " ".join(ucFirst(w) for w in x.split("_"))


def var(envVar):
    return os.environ.get(envVar, None)


def fillin(pairs, config):

    notFound = []
    found = {}
    result = {}

    varReplace = makeVarReplace(config, found, notFound)

    for k, v in pairs.items():
        if type(v) is str:
            v = VAR_RE.sub(varReplace, v)

        result[k] = v

    return notFound, found, result


def addToDict(source, additions):

    for k, v in additions.items():
        if k not in source or source[k] is None:
            source[k] = v
        else:
            sv = source[k]

            if type(sv) is dict and type(v) is dict:
                addToDict(sv, v)


def console(*msg, error=False, newline=True, sleep=None, indent=""):
    msg = " ".join(m if type(m) is str else repr(m) for m in msg)
    msg = "" if not msg else ux(msg)
    msg = msg[1:] if msg.startswith("\n") else msg
    msg = msg[0:-1] if msg.endswith("\n") else msg
    target = sys.stderr if error else sys.stdout
    nl = "\n" if newline else ""

    if indent:
        msg = indent + msg.replace("\n", f"\n{indent}")

    target.write(f"{msg}{nl}")
    target.flush()

    if sleep:
        time.sleep(sleep)


def consoleT01(msg, error=False, newline=True):
    console(msg, error=error, newline=newline, sleep=0.1)


def run(cmdline, workDir=None):
    try:
        result = run_cmd(
            cmdline,
            shell=True,
            cwd=workDir,
            check=True,
            capture_output=True,
        )
        stdOut = result.stdout.decode("utf8").strip()
        stdErr = result.stderr.decode("utf8").strip()
        returnCode = 0
        good = True

    except CalledProcessError as e:
        stdOut = e.stdout.decode("utf8").strip()
        stdErr = e.stderr.decode("utf8").strip()
        returnCode = e.returncode
        good = False

    return (good, returnCode, stdOut, stdErr)


def readCfg(settingsFile, label, verbose=0, **kwargs):
    settings = readYaml(asFile=settingsFile, **kwargs)

    if settings:
        if verbose == 1:
            console(f"{label} settings read from {settingsFile}")
        good = True
    else:
        console(f"No {label} settings found, looked for {settingsFile}", error=True)
        good = False

    return (good, settings)
