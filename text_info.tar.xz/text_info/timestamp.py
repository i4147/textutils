
import sys
import time

from .files import unexpanduser as ux


VERBOSE = "verbose"
"""Increased verbosity.
"""

AUTO = "auto"
"""Convenient level of silence.
"""

TERSE = "terse"
"""More silence.
"""

DEEP = "deep"
"""No output, except error messages.
"""

SILENT_D = AUTO
"""Default value for the silent parameter.

The value is `"terse"`
"""


def silentConvert(arg):
    if arg is None:
        return SILENT_D
    if arg is False:
        return VERBOSE
    if arg is True:
        return DEEP
    if type(arg) is str and arg in {VERBOSE, AUTO, TERSE, DEEP}:
        return arg
    return not not arg


class Timestamp:
    def __init__(self, silent=SILENT_D, level=None):
        silent = silentConvert(silent)
        indent = self.indent

        self.oneLevelRep = "   |   "
        self.timestamp = {}
        self.level = 0
        indent(level=level, reset=True)
        self.log = []
        self.verbose = -2
        self.silent = silent

    def raw_msg(self, msg, tm=True, nl=True, cache=0, error=False):
        if self.verbose != -2 and self.level >= self.verbose:
            return
        if type(msg) is not str:
            msg = repr(msg)
        msg = ux(msg)
        if tm:
            msgRep = f"{self.levelRep}{self._elapsed():>7} {msg}".replace("\n", "\n" + self.levelRep)
        else:
            msgRep = f"{self.levelRep}{msg}".replace("\n", "\n" + self.levelRep)
        if type(cache) is list:
            cache.append((error, nl, msgRep))
        else:
            if cache:
                self.log.append((error, nl, msgRep))
            if cache >= 0:
                channel = sys.stderr if error else sys.stdout
                channel.write("{}{}".format(msgRep, "\n" if nl else ""))
                channel.flush()

    def reset(self):
        self.log = []

    def cache(self, _asString=False):
        if _asString:
            lines = []
            for error, nl, msgRep in self.log:
                lines.append("{}{}".format(msgRep, "\n" if nl else ""))
            result = "".join(lines)
        else:
            for error, nl, msgRep in self.log:
                channel = sys.stderr if error else sys.stdout
                channel.write("{}{}".format(msgRep, "\n" if nl else ""))
            sys.stderr.flush()
            sys.stdout.flush()
        self.log = []
        if _asString:
            return result

    def debug(self, msg, tm=True, nl=True, cache=0, force=False):

        if force or self.silent in {VERBOSE}:
            self.raw_msg(msg, tm=tm, nl=nl, cache=cache)

    def info(self, msg, tm=True, nl=True, cache=0, force=False):

        if force or self.silent in {VERBOSE, AUTO}:
            self.raw_msg(msg, tm=tm, nl=nl, cache=cache)

    def warning(self, msg, tm=True, nl=True, cache=0, force=False):

        if force or self.silent in {VERBOSE, AUTO, TERSE}:
            self.raw_msg(msg, tm=tm, nl=nl, cache=cache)

    def error(self, msg, tm=True, nl=True, cache=0, force=True):

        self.raw_msg(msg, tm=tm, nl=nl, cache=cache, error=True)

    def indent(self, level=None, reset=False, _verbose=None):

        self.level = (
            0 if level is None else level if type(level) is int else self.level + 1 if level else self.level - 1
        )
        if self.level < 0:
            self.level = 0
        self.levelRep = self.oneLevelRep * self.level
        if reset:
            self.timestamp[self.level] = time.time()
        if _verbose is not None:
            self.verbose = _verbose

    def isSilent(self):
        return self.silent

    def setSilent(self, silent):

        silent = silentConvert(silent)
        self.silent = silent

    def silentOn(self, deep=False):

        wasSilent = self.silent
        self.wasSilent = wasSilent if wasSilent in {VERBOSE, AUTO, TERSE} else AUTO
        self.silent = DEEP if deep else TERSE

    def silentOff(self):

        wasSilent = getattr(self, "wasSilent", AUTO)
        self.silent = wasSilent

    def _elapsed(self):
        interval = time.time() - self.timestamp.setdefault(self.level, time.time())
        if interval < 10:
            return f"{interval: 2.2f}s"
        interval = int(round(interval))
        if interval < 60:
            return f"{interval:>2d}s"
        if interval < 3600:
            return f"{interval // 60:>2d}m {interval % 60:>02d}s"
        return f"{interval // 3600:>2d}h {(interval % 3600) // 60:>02d}m {interval % 60:>02d}s"
