import sys
from textwrap import dedent

from .helpers import console


# (good, tasks, params, flags, defaults) = readArgs("tf-addnlp", HELP, TASKS, PARAMS, FLAGS)


def readArgs(command, descr, possibleTasks, possibleParams, possibleFlags, notInAll=set()):

    taskArgs = set()
    helpTasks = []

    for task, helpStr in possibleTasks.items():
        helpTasks.append(f"\t{task}:\n\t\t{helpStr}\n")
        taskArgs.add(task)

    notInAllRep = f" except {', '.join(notInAll)}" if len(notInAll) else ""
    helpTasks.append(f"all:\n\t\tall tasks{notInAllRep}")
    taskArgs.add("all")

    paramArgsDef = {}
    helpParams = []

    for param, (helpStr, default) in possibleParams.items():
        helpParams.append(f"\t{param}={default}:\n\t\t{helpStr}\n")
        paramArgsDef[param] = default

    flagArgsDef = {}
    flagArgs = {}
    helpFlags = []

    for flag, (helpStr, default, nValues) in possibleFlags.items():
        helpFlags.append(f"\t{flag}={default}:\n\t\t{helpStr}\n")
        valueCoding = (
            (("-", False, "no"), ("+", True, "yes"))
            if nValues == 2
            else (("-", -1, "no"), ("+", 0, "a bit"), ("++", 1, "more"))
            if nValues == 3
            else None
        )

        if valueCoding is not None:
            for sigil, value, rep in valueCoding:
                helpFlags.append(f"\t\t{sigil}{flag}: {rep} {flag}")
                flagArgsDef[flag] = default
                flagArgs[f"{sigil}{flag}"] = value

    helpText = f"{command} [tasks/params/flags] [--help]\n\n{descr}\n\n" + dedent(
        """
        --help: show this text and exit

        tasks:
        «tasks»

        parameters:
        «params»

        flags:
        «flags»
        """
    ).replace("«tasks»", "".join(helpTasks)).replace("«params»", "".join(helpParams)).replace(
        "«flags»", "".join(helpFlags)
    )

    possibleArgs = set(taskArgs) | set(flagArgs)

    args = set(sys.argv[1:])

    if not len(args) or "--help" in args or "-h" in args:
        console(helpText)
        if not len(args):
            console("No task specified")
        return (True, {}, {}, {})

    illegalArgs = {arg for arg in args if not (arg in possibleArgs or arg.split("=", 1)[0] in paramArgsDef)}

    if len(illegalArgs):
        console(helpText)
        for arg in illegalArgs:
            console(f"Illegal argument `{arg}`")
        return (False, {}, {}, {})

    tasks = {}
    flags = {}
    params = {}

    for arg in args:
        if arg in taskArgs:
            tasks[arg] = True
        elif arg in flagArgs:
            flags[arg.lstrip("+-")] = flagArgs[arg]
        else:
            parts = arg.split("=", 1)
            (p, val) = parts
            params[p] = val or paramArgsDef[p]

    for f, default in flagArgsDef.items():
        if f not in flags:
            flags[f] = default

    for p, default in paramArgsDef.items():
        if p not in params:
            params[p] = default

    if "all" in tasks:
        if tasks["all"]:
            tasks = {arg: True for arg in possibleTasks if arg != "all" and arg not in notInAll}
        else:
            del tasks["all"]

    return (True, tasks, params, flags)
