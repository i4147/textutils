from .text2id import Text2Id
